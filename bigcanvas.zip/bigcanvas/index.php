<!DOCTYPE html>
<html>
<head>
	<title>Big Canvas</title>
	<link href="https://fonts.googleapis.com/css?family=Quicksand&display=swap" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body onscroll="myScroll()">
	<?php include('head.php') ?>

	<div id="lakers"><?php include('home.php') ?></div>
	
	<?php include('bottom.php') ?>

	<?php include('tab.php') ?>
<script src="js/main.js"></script>
</body>
</html>
