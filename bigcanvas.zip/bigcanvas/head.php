<header>
		<div class="container">
			<div id="header">
				<div id="logo">
					<a id="brand" href="#"><img src="img/thebc2.png" width="75"></a>
				</div>
				<div id="title">
					<a href="#">Big Canvas</a>
					<div id="demo"></div>
				</div>
				<nav>
					<ul>
						<li class="nav-item" id="navigation">
							<a class="links" onclick="deskhome()" href="#service">Home</a>
						</li>
						<li class="nav-item">
							<a class="links" onclick="deskgallery()" href="#about">Gallery</a>
						</li>
						<li class="nav-item">
							<a class="links" onclick="deskuser()" href="#contact">Contact Us</a>
						</li>
					</ul>
				</nav>
			</div>
			
		</div>
	</header>