<div class="tab">
			<a id="home-tab" href="#"><img src="img/home-solid.svg"></a>
			<a id="gallery-tab" href="#"><img src="img/image-regular.svg"></a>
			<a id="user-tab" href="#"><img src="img/user-solid.svg"></a>
	</div>