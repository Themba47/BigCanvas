<section class="section" id="summary">
				<div class="context">
					<div class="thesummary" id="thesocial">
						<h1>Social Media</h1>
						<div class="social-icons">
							<a href="#"><img src="img/facebook-square-brands.svg"></a>
							<a href="#"><img src="img/insta.png"></a>
							<a href="#"><img src="img/twitter-brands.svg"></a>
						</div>
					</div>
				</div>
			</section>

<footer><p>Copyright Big Canvas 2019&copy;</p></footer>
